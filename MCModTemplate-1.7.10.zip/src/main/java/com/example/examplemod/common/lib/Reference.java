package com.example.examplemod.common.lib;

import me.jezza.oc.api.configuration.Config;

public class Reference {
    public static final String MOD_ID = "examplemod";
    public static final String MOD_IDENTIFIER = MOD_ID + ":";
    public static final String MOD_VERSION = "1.0";
    public static final String MOD_NAME = "Example Mod";

    @Config.ConfigBoolean(category = "General", comment = "This is just an example config")
    public static boolean SOME_CONFIG_VALUE = false;
}
